import org.apache.spark.sql.SparkSession
object ShopOrderCount {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("ShopOrderCount")
      .master("local[1]")
      .getOrCreate()
    val sc = spark.sparkContext
    val orderRDD = sc.textFile("data/clearOrder.csv")
      .map(_.split("\t"))
      .filter(parts => parts.length == 3
        && parts(0).trim.nonEmpty
        && parts(1).trim.nonEmpty)
      .map(parts => (parts(1).trim, parts(0).trim))

    val prodRDD = sc.textFile("data/clearProducts.csv")
      .map(_.split("\t"))
      .filter(parts => parts.length == 4
        && parts(0).trim.nonEmpty
        && parts(2).trim.nonEmpty)
      .map(parts => (parts(0).trim, parts(2).trim))  // (product_id, price)

    val result = orderRDD.join(prodRDD)       // (product_id, (user_id, price))
      .map { case (_, (_, price)) => (price, 1) }
      .reduceByKey(_ + _)
      .sortBy(_._2, ascending = false)
      .map { case (price, cnt) => s"$price\t$cnt" }

    result.coalesce(1).saveAsTextFile("files_order/price_order_count")

    sc.stop()
  }
}