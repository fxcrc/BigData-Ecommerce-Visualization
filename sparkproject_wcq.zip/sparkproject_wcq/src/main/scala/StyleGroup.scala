import org.apache.spark.sql.SparkSession

object StyleGroup {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("StyleGroup")
      .master("local[1]")
      .getOrCreate()

    val sc = spark.sparkContext

    val result = sc.textFile("data/clearProducts.csv")
      .map(_.split("\t"))
      .filter(parts => parts.length >= 3
        && parts(1).trim.nonEmpty
        && parts(2).trim.nonEmpty)
      .map(parts => (parts(2).trim, parts(1).trim))
      .reduceByKey((a, b) => a + b)
      .map { case (price, style) => s"$price\t$style" }
      .sortBy(x => x)

    result.coalesce(1).saveAsTextFile("files_order/style_group_output")

    sc.stop()
  }
}