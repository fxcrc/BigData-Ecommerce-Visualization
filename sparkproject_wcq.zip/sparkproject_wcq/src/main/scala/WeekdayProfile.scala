import org.apache.spark.{SparkConf, SparkContext}
import java.util.{Calendar, Date}

object WeekdayProfile {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
      .setAppName("WeekdayProfile")
      .setMaster("local[1]")
    val sc = new SparkContext(conf)

    val result = sc.textFile("data/orders.txt")
      .map(_.split("\t"))
      .filter(parts => parts.length >= 2
        && parts(0).trim.nonEmpty
        && parts(1).trim.nonEmpty)
      .map(parts => {
        val uid = parts(0).trim
        val timestamp = parts(1).trim.toLong * 1000L
        val cal = Calendar.getInstance()
        cal.setTime(new Date(timestamp))
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        ((uid, dayOfWeek), 1)
      })
      .reduceByKey(_ + _)
      .map { case ((uid, wd), cnt) => s"(($uid,$wd),$cnt)" }
      .sortBy(x => x)
    result.coalesce(1).saveAsTextFile("files_order/weekday_profile")
    //result.foreach(println)
    sc.stop()
  }
}