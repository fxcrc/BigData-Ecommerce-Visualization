import org.apache.spark.sql.SparkSession

object DataClean {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("DataClean")
      .master("local[1]")
      .getOrCreate()
    val sc = spark.sparkContext
    val orderRDD = sc.textFile("data/order_goods.txt")
      .map(_.split("\t"))
      .filter(parts =>
        parts.length == 3 &&
          parts(0).trim.nonEmpty &&
          parts(1).trim.nonEmpty &&
          parts(2).trim.nonEmpty
      )
      .map(parts => parts.map(_.trim).mkString("\t"))

    val prodRDD = sc.textFile("data/products.txt")
      .map(_.split("\t"))
      .filter(parts =>
        parts.length == 4 &&
          parts(0).trim.nonEmpty &&
          parts(1).trim.nonEmpty &&
          parts(2).trim.nonEmpty &&
          parts(3).trim.nonEmpty
      )
      .map(parts => parts.map(_.trim).mkString("\t"))
    orderRDD.saveAsTextFile("files_order/cleared_order")
    prodRDD.saveAsTextFile("files_order/cleared_products")

    //println(s"order_goods 清洗后: ${orderRDD.count()} 行")
   // println(s"products 清洗后: ${prodRDD.count()} 行")

    sc.stop()
  }
}
