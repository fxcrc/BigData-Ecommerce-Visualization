import org.apache.spark.sql.SparkSession

object UserStyleProfile {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("UserStyleProfile")
      .master("local[1]")
      .getOrCreate()

    val sc = spark.sparkContext

    val orderRDD = sc.textFile("data/clearOrder.csv")
      .map(_.split("\t"))
      .filter(parts => parts.length == 3
        && parts(0).trim.nonEmpty
        && parts(1).trim.nonEmpty)
      .map(parts => (parts(1).trim, parts(0).trim))  // (product_id, user_id)

    val prodRDD = sc.textFile("data/clearProducts.csv")
      .map(_.split("\t"))
      .filter(parts => parts.length == 4
        && parts(0).trim.nonEmpty
        && parts(1).trim.nonEmpty)
      .map(parts => (parts(0).trim, parts(1).trim))  // (product_id, style)

    val result = orderRDD.join(prodRDD)
      .map { case (_, (userId, style)) => (userId, style) }.reduceByKey((a, b) => b + a).map { case (userId, styles) =>
        val deduped = styles.split(";")
          .map(_.trim)
          .filter(_.nonEmpty)
          .distinct
          .mkString(";")
        s"($userId, $deduped)"
      }
    result.coalesce(1).saveAsTextFile("files_order/user_style_profile")
    sc.stop()
  }
}