import org.apache.spark.sql.SparkSession
import java.util.{Calendar, Date}

object WeekdayProfile {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("WeekdayProfile")
      .getOrCreate()
    val sc = spark.sparkContext
    val result = sc.textFile("hdfs:///user/hadoop/data/orders.txt")
      .map(_.split("\t"))
      .filter(parts => parts.length >= 2
        && parts(0).trim.nonEmpty
        && parts(1).trim.nonEmpty)
      .map(parts => {
        val userId = parts(0).trim
        val timestamp = parts(1).trim.toLong * 1000L  // 秒转毫秒

        val cal = Calendar.getInstance()
        cal.setTime(new Date(timestamp))
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)

        val weekday = dayOfWeek match {
          case 1 => 7
          case n => n - 1
        }

        ((userId, weekday), 1)
      })
      .reduceByKey(_ + _)
      .map { case ((userId, weekday), cnt) => (userId, (weekday, cnt)) }
      .reduceByKey((a, b) => if (a._2 >= b._2) a else b)
      .map { case (userId, (weekday, cnt)) =>
        val isWeekend = if (weekday >= 6) "周末" else "工作日"
        s"(($userId,$weekday),$cnt)"
      }
      .sortBy(x => x)
    result.coalesce(1).saveAsTextFile("hdfs:///user/hadoop/output/weekday_profile")
    sc.stop()
  }
}