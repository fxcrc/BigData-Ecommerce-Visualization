import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class ShopOrderCountDriver {

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        Path tmp = new Path("file_order/price_order_count_tmp");

        Job j1 = Job.getInstance(conf, "ShopOrderCount-Join");
        j1.setJarByClass(ShopOrderCountDriver.class);
        j1.setReducerClass(ShopOrderCountJoinReducer.class);
        j1.setMapOutputKeyClass(Text.class);
        j1.setMapOutputValueClass(Text.class);
        j1.setOutputKeyClass(Text.class);
        j1.setOutputValueClass(IntWritable.class);
        MultipleInputs.addInputPath(j1, new Path("data/clearOrder.csv"),   TextInputFormat.class, ShopOrderCountOrderMapper.class);
        MultipleInputs.addInputPath(j1, new Path("data/clearProducts.csv"), TextInputFormat.class, ShopOrderCountProductMapper.class);
        FileOutputFormat.setOutputPath(j1, tmp);
        j1.waitForCompletion(true);

        Job j2 = Job.getInstance(conf, "ShopOrderCount-Sort");
        j2.setJarByClass(ShopOrderCountDriver.class);
        j2.setMapperClass(ShopOrderCountSortMapper.class);
        j2.setReducerClass(ShopOrderCountSortReducer.class);
        j2.setNumReduceTasks(1);
        j2.setOutputKeyClass(Text.class);
        j2.setOutputValueClass(IntWritable.class);
        FileInputFormat.addInputPath(j2, tmp);
        FileOutputFormat.setOutputPath(j2, new Path("file_order/price_order_count"));
        j2.waitForCompletion(true);
        FileSystem.get(conf).delete(tmp, true);
    }
}
