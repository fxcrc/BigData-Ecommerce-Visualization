import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class UserStyleProfileStyleMapper extends Mapper<LongWritable, Text, Text, Text> {

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        String[] p = value.toString().split("\t", 2);
        if (p.length == 2)
            context.write(new Text(p[0].trim()), new Text(p[1].trim()));
    }
}
