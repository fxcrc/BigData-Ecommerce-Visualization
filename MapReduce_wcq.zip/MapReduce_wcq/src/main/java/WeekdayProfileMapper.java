import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.util.Calendar;

public class WeekdayProfileMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

    private final Calendar cal = Calendar.getInstance();

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        String[] p = value.toString().split("\t");
        if (p.length >= 2 && !p[0].trim().isEmpty() && !p[1].trim().isEmpty()) {
            try {
                cal.setTimeInMillis(Long.parseLong(p[1].trim()) * 1000L);
                int dow = cal.get(Calendar.DAY_OF_WEEK); // 1=Sun
                int weekday = (dow == 1) ? 7 : dow - 1;
                context.write(new Text(p[0].trim()), new IntWritable(weekday));
            } catch (NumberFormatException ignored) {}
        }
    }
}
