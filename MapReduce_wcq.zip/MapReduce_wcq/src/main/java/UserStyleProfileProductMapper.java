import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class UserStyleProfileProductMapper extends Mapper<LongWritable, Text, Text, Text> {

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        String[] p = value.toString().split("\t");
        if (p.length == 4 && !p[0].trim().isEmpty() && !p[1].trim().isEmpty())
            context.write(new Text(p[0].trim()), new Text("P:" + p[1].trim()));
    }
}
