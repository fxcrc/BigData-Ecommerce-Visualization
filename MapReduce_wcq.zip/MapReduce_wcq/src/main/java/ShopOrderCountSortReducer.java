import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ShopOrderCountSortReducer extends Reducer<Text, IntWritable, Text, IntWritable> {

    private final List<String> prices = new ArrayList<>();
    private final List<Integer> counts = new ArrayList<>();

    @Override
    protected void reduce(Text key, Iterable<IntWritable> values, Context context) {
        int total = 0;
        for (IntWritable v : values) total += v.get();
        prices.add(key.toString());
        counts.add(total);
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        List<Integer> idx = new ArrayList<>();
        for (int i = 0; i < prices.size(); i++) idx.add(i);
        idx.sort((a, b) -> counts.get(b) - counts.get(a));
        for (int i : idx)
            context.write(new Text(prices.get(i)), new IntWritable(counts.get(i)));
    }
}
