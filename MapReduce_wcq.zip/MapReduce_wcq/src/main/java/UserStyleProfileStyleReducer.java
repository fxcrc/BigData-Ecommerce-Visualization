import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.Set;

public class UserStyleProfileStyleReducer extends Reducer<Text, Text, NullWritable, Text> {

    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context)
            throws IOException, InterruptedException {
        StringBuilder sb = new StringBuilder();
        for (Text v : values) sb.append(v.toString());

        Set<String> seen = new LinkedHashSet<>();
        for (String s : sb.toString().split(";")) {
            String t = s.trim();
            if (!t.isEmpty()) seen.add(t);
        }
        context.write(NullWritable.get(),
                new Text("(" + key + ", " + String.join(";", seen) + ")"));
    }
}
