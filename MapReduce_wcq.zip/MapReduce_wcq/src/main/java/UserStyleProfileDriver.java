import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class UserStyleProfileDriver {

    public static void main(String[] args) throws Exception {
        //System.setProperty("hadoop.home.dir", "D:/hadoop-winutils");
        Configuration conf = new Configuration();
        Path tmp = new Path("user_style_profile_tmp" );

        // Job 1: reduce-side join → (user_id, style)
        Job j1 = Job.getInstance(conf, "UserStyleProfile-Join");
        j1.setJarByClass(UserStyleProfileDriver.class);
        j1.setReducerClass(UserStyleProfileJoinReducer.class);
        j1.setMapOutputKeyClass(Text.class);
        j1.setMapOutputValueClass(Text.class);
        j1.setOutputKeyClass(Text.class);
        j1.setOutputValueClass(Text.class);
        MultipleInputs.addInputPath(j1, new Path("data/clearOrder.csv"),    TextInputFormat.class, UserStyleProfileOrderMapper.class);
        MultipleInputs.addInputPath(j1, new Path("data/clearProducts.csv"), TextInputFormat.class, UserStyleProfileProductMapper.class);
        FileOutputFormat.setOutputPath(j1, tmp);
        j1.waitForCompletion(true);

        // Job 2: 按用户聚合风格并去重输出
        Job j2 = Job.getInstance(conf, "UserStyleProfile-Aggregate");
        j2.setJarByClass(UserStyleProfileDriver.class);
        j2.setMapperClass(UserStyleProfileStyleMapper.class);
        j2.setReducerClass(UserStyleProfileStyleReducer.class);
        j2.setMapOutputKeyClass(Text.class);
        j2.setMapOutputValueClass(Text.class);
        j2.setOutputKeyClass(NullWritable.class);
        j2.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(j2, tmp);
        FileOutputFormat.setOutputPath(j2, new Path("file_order/user_style_profile"));
        j2.waitForCompletion(true);

        FileSystem.get(conf).delete(tmp, true);
    }
}
