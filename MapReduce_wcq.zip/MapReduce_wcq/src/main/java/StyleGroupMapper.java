import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

// clearProducts.csv (product_id\tstyle\tprice\tshop) → (price, style)
public class StyleGroupMapper extends Mapper<LongWritable, Text, Text, Text> {

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        String[] p = value.toString().split("\t");
        if (p.length >= 3 && !p[1].trim().isEmpty() && !p[2].trim().isEmpty())
            context.write(new Text(p[2].trim()), new Text(p[1].trim()));
    }
}
