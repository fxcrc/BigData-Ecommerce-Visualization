import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class StyleGroupDriver {

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "StyleGroup");

        job.setJarByClass(StyleGroupDriver.class);
        job.setMapperClass(StyleGroupMapper.class);
        job.setReducerClass(StyleGroupReducer.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        FileInputFormat.addInputPath(job, new Path("data/clearProducts.csv"));
        FileOutputFormat.setOutputPath(job, new Path("file_order/style_group_output"));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
