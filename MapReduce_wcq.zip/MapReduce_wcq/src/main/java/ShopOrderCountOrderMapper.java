import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

// clearOrder.csv (user_id\tproduct_id\taddress) → (product_id, "O")
public class ShopOrderCountOrderMapper extends Mapper<LongWritable, Text, Text, Text> {

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        String[] p = value.toString().split("\t");
        if (p.length == 3 && !p[0].trim().isEmpty() && !p[1].trim().isEmpty())
            context.write(new Text(p[1].trim()), new Text("O"));
    }
}
