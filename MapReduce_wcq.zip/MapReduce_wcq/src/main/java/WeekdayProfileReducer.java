import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class WeekdayProfileReducer extends Reducer<Text, IntWritable, Text, NullWritable> {

    @Override
    protected void reduce(Text key, Iterable<IntWritable> values, Context context)
            throws IOException, InterruptedException {
        Map<Integer, Integer> counts = new HashMap<>();
        for (IntWritable v : values)
            counts.merge(v.get(), 1, Integer::sum);

        int bestDay = -1, bestCnt = -1;
        for (Map.Entry<Integer, Integer> e : counts.entrySet()) {
            if (e.getValue() > bestCnt || (e.getValue() == bestCnt && e.getKey() < bestDay)) {
                bestCnt = e.getValue();
                bestDay = e.getKey();
            }
        }
        context.write(new Text("((" + key + "," + bestDay + ")," + bestCnt + ")"), NullWritable.get());
    }
}
