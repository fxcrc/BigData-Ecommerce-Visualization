import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

// 读取 Job1 输出 (price\tcount) → (price, count)
public class ShopOrderCountSortMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        String[] p = value.toString().split("\t");
        if (p.length == 2)
            context.write(new Text(p[0].trim()), new IntWritable(Integer.parseInt(p[1].trim())));
    }
}
