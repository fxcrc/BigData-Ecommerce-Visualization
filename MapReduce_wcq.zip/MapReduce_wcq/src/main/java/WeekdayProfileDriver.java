import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class WeekdayProfileDriver {

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "WeekdayProfile");

        job.setJarByClass(WeekdayProfileDriver.class);
        job.setMapperClass(WeekdayProfileMapper.class);
        job.setReducerClass(WeekdayProfileReducer.class);

        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(NullWritable.class);

        FileInputFormat.addInputPath(job, new Path("data/orders.txt"));
        FileOutputFormat.setOutputPath(job, new Path("file_order/weekday_profile"));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
