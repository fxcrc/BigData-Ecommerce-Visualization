import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

// 按 product_id 合并：统计 O 的数量，取 P 的 price，输出 (price, 订单数)
public class ShopOrderCountJoinReducer extends Reducer<Text, Text, Text, IntWritable> {

    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context)
            throws IOException, InterruptedException {
        String price = null;
        int cnt = 0;
        for (Text v : values) {
            String s = v.toString();
            if (s.startsWith("P:")) price = s.substring(2);
            else cnt++;
        }
        if (price != null && cnt > 0)
            context.write(new Text(price), new IntWritable(cnt));
    }
}
