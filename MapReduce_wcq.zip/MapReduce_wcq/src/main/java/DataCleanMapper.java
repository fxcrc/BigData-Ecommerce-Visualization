import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class DataCleanMapper extends Mapper<LongWritable, Text, NullWritable, Text> {

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        String[] p = value.toString().split("\t");
        if (p.length == 4
                && !p[0].trim().isEmpty()
                && !p[1].trim().isEmpty()
                && !p[2].trim().isEmpty()
                && !p[3].trim().isEmpty()) {
            context.write(NullWritable.get(),
                    new Text(p[0].trim() + "\t" + p[1].trim() + "\t" + p[2].trim() + "\t" + p[3].trim()));
        }
    }
}
