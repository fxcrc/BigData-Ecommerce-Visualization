import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class UserStyleProfileJoinReducer extends Reducer<Text, Text, Text, Text> {

    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context)
            throws IOException, InterruptedException {
        String style = null;
        List<String> users = new ArrayList<>();
        for (Text v : values) {
            String s = v.toString();
            if (s.startsWith("P:")) style = s.substring(2);
            else users.add(s.substring(2));
        }
        if (style != null)
            for (String u : users)
                context.write(new Text(u), new Text(style));
    }
}