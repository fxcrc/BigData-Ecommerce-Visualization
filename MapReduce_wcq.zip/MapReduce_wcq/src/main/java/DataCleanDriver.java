import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class DataCleanDriver {

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();

        // Job 1: 清洗 order_goods.txt → cleared_order
        Job j1 = Job.getInstance(conf, "DataClean-Order");
        j1.setJarByClass(DataCleanDriver.class);
        j1.setMapperClass(DataCleanOrderMapper.class);
        j1.setNumReduceTasks(0);
        j1.setOutputKeyClass(NullWritable.class);
        j1.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(j1, new Path("data/order_goods.txt"));
        FileOutputFormat.setOutputPath(j1, new Path("file_order/cleared_order"));
        j1.waitForCompletion(true);

        // Job 2: 清洗 products.txt → cleared_products
        Job j2 = Job.getInstance(conf, "DataClean-Products");
        j2.setJarByClass(DataCleanDriver.class);
        j2.setMapperClass(DataCleanMapper.class);
        j2.setNumReduceTasks(0);
        j2.setOutputKeyClass(NullWritable.class);
        j2.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(j2, new Path("data/products.txt"));
        FileOutputFormat.setOutputPath(j2, new Path("file_order/cleared_products"));
        j2.waitForCompletion(true);
    }
}
