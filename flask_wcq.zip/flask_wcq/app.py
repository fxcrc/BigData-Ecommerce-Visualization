# app.py
# 修正后的app.py - 解决ID与价格混淆问题，优化前后端数据交互
from flask import Flask, render_template, Blueprint, jsonify, request
import pymysql
from pymysql.cursors import DictCursor
import logging
# 初始化日志
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
app = Flask(__name__)
app.config["SECRET_KEY"] = "spark-data-visual-2026"
app.config["JSON_AS_ASCII"] = False
# 数据库配置
DB_CONFIG = {
    "host": "192.168.168.146",
    "port": 3306,
    "user": "local-spark",
    "password": "120903",
    "database": "local-spark",
    "charset": "utf8mb4"
}

mine_bp = Blueprint("mine", __name__, url_prefix="")

@mine_bp.route("/dashboard")
def dashboard():
    # 1. 总订单量
    total_order = mysql_query("SELECT SUM(order_count) total FROM price_order_count")[0]["total"] or 0
    # 2. 平均客单价 - 修正：加权平均计算，确保统计真实价格，而非ID
    price_order_data = mysql_query("SELECT price, order_count FROM price_order_count")
    total_amount = 0
    total_cnt = 0
    for row in price_order_data:
        price = float(row["price"]) if row["price"] else 0
        cnt = int(row["order_count"]) if row["order_count"] else 0
        total_amount += price * cnt
        total_cnt += cnt
    avg_price = round(total_amount / total_cnt, 2) if total_cnt > 0 else 0
    # 3. 穿搭风格统计，过滤空值
    style_raw = mysql_query("SELECT DISTINCT styles FROM user_style_profile WHERE styles IS NOT NULL AND styles != ''")
    style_count = {}
    for row in style_raw:
        styles_str = row["styles"]
        style_list = [s.strip() for s in styles_str.split(";") if s.strip()]
        for s in style_list:
            style_count[s] = style_count.get(s, 0) + 1
    # 按热度倒序取TOP5
    top_style_list = sorted(style_count.items(), key=lambda x: x[1], reverse=True)[:5]
    top_style_with_index = [
        {"rank": idx + 1, "name": name, "num": num}
        for idx, (name, num) in enumerate(top_style_list)
    ]
    # 顶部卡片兜底
    if top_style_list:
        top1_name = top_style_list[0][0]
        top1_count = top_style_list[0][1]
    else:
        top1_name = "无"
        top1_count = 0
    # 4. 周度订单数据
    week_data = mysql_query("SELECT weekday, SUM(order_count) total FROM weekday_profile GROUP BY weekday ORDER BY weekday")
    week_list = [i["weekday"] for i in week_data]
    week_cnt = [int(i["total"]) for i in week_data]
    # 5. 价格区间订单 - 修正：数值型排序，避免ID与价格混淆
    price_data = mysql_query("SELECT price, order_count FROM price_order_count ORDER BY CAST(price AS DECIMAL(10,2))")
    price_list = [r["price"] for r in price_data]
    order_cnt = [int(r["order_count"]) for r in price_data]
    return render_template(
        "page/mine/dashboard.html",
        total_order=total_order,
        avg_price=avg_price,
        top_style=top_style_with_index,
        top1_name=top1_name,
        top1_count=top1_count,
        week=week_list,
        week_count=week_cnt,
        price=price_list,
        order_cnt=order_cnt
    )
# 商户订单统计柱状图 - 修正价格排序逻辑
@mine_bp.route("/shop_order")
def shop_order():
    sql = "SELECT price, order_count FROM price_order_count ORDER BY CAST(price AS DECIMAL(10,2));"
    res = mysql_query(sql)
    price_list = [row["price"] for row in res]
    cnt_list = [int(row["order_count"]) for row in res]
    return render_template("page/mine/shop_order.html", price=price_list, order_cnt=cnt_list)

@mine_bp.route("/shop_style")
def shop_style():

    style_raw = mysql_query("SELECT styles FROM user_style_profile WHERE styles IS NOT NULL AND styles != ''")
    style_count = {}
    for row in style_raw:
        styles_str = row["styles"]
        style_list = [s.strip() for s in styles_str.split(";") if s.strip()]
        for s in style_list:
            style_count[s] = style_count.get(s, 0) + 1

    style_data = [{"name": name, "value": num} for name, num in style_count.items()]
    return render_template("page/mine/shop_style.html", style_data=style_data)
# 用户穿搭画像
@mine_bp.route("/user_style")
def user_style():
    sql = "SELECT DISTINCT styles FROM user_style_profile WHERE styles IS NOT NULL AND styles != ''"
    res = mysql_query(sql)
    style_data = [row["styles"] for row in res if row["styles"] is not None]
    return render_template("page/mine/user_style.html", style_data=style_data)
# 用户周消费时段折线图
@mine_bp.route("/user_weekday")
def user_weekday():
    sql = "SELECT weekday, SUM(order_count) total FROM weekday_profile GROUP BY weekday ORDER BY weekday;"
    res = mysql_query(sql)
    week_list = [i["weekday"] for i in res]
    count_list = [int(i["total"]) for i in res]
    return render_template("page/mine/user_weekday.html", week=week_list, count=count_list)
# ---------------------- 蓝图路由写完，再执行注册 ----------------------
app.register_blueprint(mine_bp)
# 通用安全查询工具（参数化SQL，防注入，自动释放连接）
def mysql_query(sql, params=None):
    params = params or ()
    try:
        with pymysql.connect(**DB_CONFIG) as conn:
            with conn.cursor(DictCursor) as cur:
                logging.info(f"执行SQL：{sql} 参数：{params}")
                cur.execute(sql, params)
                data = cur.fetchall()
                logging.info(f"查询结果行数：{len(data)}")
                return data
    except Exception as e:
        logging.error(f"数据库查询异常：{type(e).__name__}: {str(e)}")
        return []
# 全局异常捕获
@app.errorhandler(Exception)
def handle_exception(e):
    logging.error(f"全局异常：{str(e)}")
    return "<h2>服务器数据查询异常，请联系管理员</h2>", 500
# 系统健康检查接口
@app.route("/health")
def health():
    test_data = mysql_query("SELECT 1 as ok")
    if test_data:
        return jsonify({"code": 200, "msg": "服务正常", "db": "connected"})
    return jsonify({"code": 500, "msg": "数据库连接失败", "db": "disconnect"}), 500
# 后台框架首页
@app.route("/")
def index():
    return render_template("index.html")
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)