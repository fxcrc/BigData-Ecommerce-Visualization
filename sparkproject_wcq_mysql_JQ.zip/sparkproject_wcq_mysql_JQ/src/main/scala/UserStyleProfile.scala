import org.apache.spark.sql.SparkSession

object UserStyleProfile {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("UserStyleProfile")
      .getOrCreate()

    val sc = spark.sparkContext
    import spark.implicits._

    val url = "jdbc:mysql://192.168.168.146:3306/local-spark?useSSL=false&characterEncoding=utf8&allowPublicKeyRetrieval=true"
    val props = new java.util.Properties()
    props.put("user", "local-spark")
    props.put("password", "120903")
    props.put("driver", "com.mysql.cj.jdbc.Driver")

    val orderRDD = sc.textFile("hdfs:///user/hadoop/data/clearOrder.csv")
      .map(_.split("\t"))
      .filter(parts => parts.length == 3
        && parts(0).trim.nonEmpty
        && parts(1).trim.nonEmpty)
      .map(parts => (parts(1).trim, parts(0).trim))

    val prodRDD = sc.textFile("hdfs:///user/hadoop/data/clearProducts.csv")
      .map(_.split("\t"))
      .filter(parts => parts.length == 4
        && parts(0).trim.nonEmpty
        && parts(1).trim.nonEmpty)
      .map(parts => (parts(0).trim, parts(1).trim))

    val result = orderRDD.join(prodRDD)
      .map { case (_, (userId, style)) => (userId, style) }
      .reduceByKey((a, b) => b + a)
      .map { case (userId, styles) =>
        val deduped = styles.split(";")
          .map(_.trim)
          .filter(_.nonEmpty)
          .distinct
          .mkString(";")
        (userId, deduped)
      }

    val df = result.toDF("user_id", "styles")
    df.coalesce(1).write.mode("overwrite")
      .jdbc(url, "user_style_profile", props)
    df.coalesce(1).write.mode("overwrite")
      .option("sep", "\t")
      .csv("hdfs:///user/hadoop/output/user_style_profile")

    println("UserStyleProfile 完成")
    sc.stop()
  }
}