import org.apache.spark.sql.SparkSession

object ShopOrderCount {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("ShopOrderCount")
      .getOrCreate()

    val sc = spark.sparkContext
    import spark.implicits._

    val url = "jdbc:mysql://192.168.168.146:3306/local-spark?useSSL=false&characterEncoding=utf8&allowPublicKeyRetrieval=true"
    val props = new java.util.Properties()
    props.put("user", "local-spark")
    props.put("password", "120903")
    props.put("driver", "com.mysql.cj.jdbc.Driver")

    val orderRDD = sc.textFile("hdfs:///user/hadoop/data/clearOrder.csv")
      .map(_.split("\t"))
      .filter(parts => parts.length == 3
        && parts(0).trim.nonEmpty
        && parts(1).trim.nonEmpty)
      .map(parts => (parts(1).trim, parts(0).trim))

    val prodRDD = sc.textFile("hdfs:///user/hadoop/data/clearProducts.csv")
      .map(_.split("\t"))
      .filter(parts => parts.length == 4
        && parts(0).trim.nonEmpty
        && parts(2).trim.nonEmpty)
      .map(parts => (parts(0).trim, parts(2).trim))

    val result = orderRDD.join(prodRDD)
      .map { case (_, (_, price)) => (price, 1) }
      .reduceByKey(_ + _)
      .sortBy(_._2, ascending = false)

    val df = result.toDF("price", "order_count")
    df.coalesce(1).write.mode("overwrite")
      .jdbc(url, "price_order_count", props)
    df.coalesce(1).write.mode("overwrite")
      .option("sep", "\t")
      .csv("hdfs:///user/hadoop/output/price_order_count")

    println("ShopOrderCount 完成")
    sc.stop()
  }
}