import org.apache.spark.sql.SparkSession
import java.util.{Calendar, Date}

object WeekdayProfile {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("WeekdayProfile")
      .getOrCreate()

    val sc = spark.sparkContext
    import spark.implicits._

    val url = "jdbc:mysql://192.168.168.146:3306/local-spark?useSSL=false&characterEncoding=utf8&allowPublicKeyRetrieval=true"
    val props = new java.util.Properties()
    props.put("user", "local-spark")
    props.put("password", "120903")
    props.put("driver", "com.mysql.cj.jdbc.Driver")

    val result = sc.textFile("hdfs:///user/hadoop/data/orders.txt")
      .map(_.split("\t"))
      .filter(parts => parts.length >= 2
        && parts(0).trim.nonEmpty
        && parts(1).trim.nonEmpty)
      .map(parts => {
        val userId = parts(0).trim
        val timestamp = parts(1).trim.toLong * 1000L

        val cal = Calendar.getInstance()
        cal.setTime(new Date(timestamp))
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)

        val weekday = dayOfWeek match {
          case 1 => 7
          case n => n - 1
        }

        ((userId, weekday), 1)
      })
      .reduceByKey(_ + _)
      .map { case ((userId, weekday), cnt) => (userId, weekday, cnt) }

    val df = result.toDF("user_id", "weekday", "order_count")
    df.coalesce(1).write.mode("overwrite")
      .jdbc(url, "weekday_profile", props)
    df.coalesce(1).write.mode("overwrite")
      .option("sep", "\t")
      .csv("hdfs:///user/hadoop/output/weekday_profile")

    println("WeekdayProfile 完成")
    sc.stop()
  }
}