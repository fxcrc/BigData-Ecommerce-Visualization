import org.apache.spark.sql.SparkSession

object StyleGroup {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("StyleGroup")
      .getOrCreate()

    val sc = spark.sparkContext
    import spark.implicits._

    val url = "jdbc:mysql://192.168.168.146:3306/local-spark?useSSL=false&characterEncoding=utf8&allowPublicKeyRetrieval=true"
    val props = new java.util.Properties()
    props.put("user", "local-spark")
    props.put("password", "120903")
    props.put("driver", "com.mysql.cj.jdbc.Driver")

    val result = sc.textFile("hdfs:///user/hadoop/data/clearProducts.csv")
      .map(_.split("\t"))
      .filter(parts => parts.length >= 3
        && parts(1).trim.nonEmpty
        && parts(2).trim.nonEmpty)
      .map(parts => (parts(2).trim, parts(1).trim))
      .reduceByKey((a, b) => a + b)

    val df = result.toDF("price", "styles")
    df.coalesce(1).write.mode("overwrite")
      .jdbc(url, "style_group_output", props)
    df.coalesce(1).write.mode("overwrite")
      .option("sep", "\t")
      .csv("hdfs:///user/hadoop/output/style_group_output")

    println("StyleGroup 完成")
    sc.stop()
  }
}