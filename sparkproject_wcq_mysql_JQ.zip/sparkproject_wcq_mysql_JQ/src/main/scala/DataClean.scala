import org.apache.spark.sql.SparkSession

object DataClean {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("DataClean")
      .getOrCreate()

    val sc = spark.sparkContext
    import spark.implicits._

    val url = "jdbc:mysql://192.168.168.146:3306/local-spark?useSSL=false&characterEncoding=utf8&allowPublicKeyRetrieval=true"
    val props = new java.util.Properties()
    props.put("user", "local-spark")
    props.put("password", "120903")
    props.put("driver", "com.mysql.cj.jdbc.Driver")

    val orderRDD = sc.textFile("hdfs:///user/hadoop/data/order_goods.txt")
      .map(_.split("\t"))
      .filter(parts => parts.length == 3
        && parts(0).trim.nonEmpty
        && parts(1).trim.nonEmpty
        && parts(2).trim.nonEmpty)
      .map(parts => (parts(0).trim, parts(1).trim, parts(2).trim))

    val orderDF = orderRDD.toDF("user_id", "product_id", "address")
    orderDF.coalesce(1).write.mode("overwrite")
      .jdbc(url, "cleared_order", props)
    orderDF.coalesce(1).write.mode("overwrite")
      .option("sep", "\t")
      .csv("hdfs:///user/hadoop/output/cleared_order")

    val prodRDD = sc.textFile("hdfs:///user/hadoop/data/products.txt")
      .map(_.split("\t"))
      .filter(parts => parts.length == 4
        && parts(0).trim.nonEmpty
        && parts(1).trim.nonEmpty
        && parts(2).trim.nonEmpty
        && parts(3).trim.nonEmpty)
      .map(parts => (parts(0).trim, parts(1).trim, parts(2).trim, parts(3).trim))

    val prodDF = prodRDD.toDF("product_id", "style", "price", "origin")
    prodDF.coalesce(1).write.mode("overwrite")
      .jdbc(url, "cleared_products", props)
    prodDF.coalesce(1).write.mode("overwrite")
      .option("sep", "\t")
      .csv("hdfs:///user/hadoop/output/cleared_products")

    println("DataClean 完成")
    sc.stop()
  }
}